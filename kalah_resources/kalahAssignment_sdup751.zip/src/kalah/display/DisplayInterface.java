package kalah.display;

public interface DisplayInterface {

    void printBoard();

    void printScore();

    void houseDoesNotExist();

    void invalidMoveMade();
}
