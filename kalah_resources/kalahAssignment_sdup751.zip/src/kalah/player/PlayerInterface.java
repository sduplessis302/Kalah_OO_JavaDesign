package kalah.player;

public interface PlayerInterface {

    String promptHumanPlayer();

}
