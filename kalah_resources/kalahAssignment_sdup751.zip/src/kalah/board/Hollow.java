package kalah.board;

public class Hollow extends StorageElement {

    public Hollow(int player, int seeds) {
        super(player, seeds);
    }

}
