package kalah.board;

public enum NextTurn {
    NextPlayer,
    MoveAgain,
    HouseEmpty,
}
