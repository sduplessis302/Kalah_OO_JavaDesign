package kalah.board;

public class Bank extends StorageElement {

    public Bank(int player, int seeds) {
        super(player, seeds);
    }

}
